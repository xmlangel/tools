#!/usr/bin/env python3
import os
import xml.etree.ElementTree as ET
from pathlib import Path

def generate_junit(regress_dir):
    testsuite = ET.Element('testsuite', name='pg_regress', tests=str(1000), failures='0')  # 실제 수 맞춤
    
    # regression.log 파싱 예시
    log_path = Path(regress_dir) / 'log' / 'regression.log'
    if log_path.exists():
        with open(log_path) as f:
            content = f.read()
        failed = content.count('FAILED')
        testsuite.set('failures', str(failed))
    
    # diffs에서 실패 케이스 추가
    diffs_path = Path(regress_dir) / 'regression.diffs'
    if diffs_path.exists():
        with open(diffs_path) as f:
            cases = [line for line in f if '---' in line and '----' in line]
        for i, case in enumerate(cases[:10]):  # top 10 failures
            testcase = ET.SubElement(testsuite, 'testcase', classname='regression', name=f'case_{i+1}')
            failure = ET.SubElement(testcase, 'failure', message='diff mismatch')
    
    tree = ET.ElementTree(testsuite)
    tree.write('TEST-pg_regress.xml', encoding='utf-8', xml_declaration=True)

generate_junit('.')
