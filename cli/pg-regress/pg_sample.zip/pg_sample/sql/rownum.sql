DROP TABLE IF EXISTS EMP_P;

CREATE TABLE EMP_P
       (EMPNO NUMBER(4) CONSTRAINT PK_EMP_P PRIMARY KEY,
	ENAME VARCHAR2(25),
	JOB VARCHAR2(14),
	MGR NUMBER(4),
	HIREDATE DATE,
	SAL NUMBER(7,2) ,
	COMM NUMBER(7,2),
	DEPTNO NUMBER(2));

INSERT INTO EMP_P VALUES
(7369,'SMITH','CLERK',7902,to_date('17-12-1980','dd-mm-yyyy'),800,NULL,20);
INSERT INTO EMP_P VALUES
(7499,'ALLEN','SALESMAN',7698,to_date('20-2-1981','dd-mm-yyyy'),1600,300,30);
INSERT INTO EMP_P VALUES
(7521,'WARD','SALESMAN',7698,to_date('22-2-1981','dd-mm-yyyy'),1250,500,30);
INSERT INTO EMP_P VALUES
(7566,'JONES','MANAGER',7839,to_date('2-4-1981','dd-mm-yyyy'),2975,NULL,20);
INSERT INTO EMP_P VALUES
(7654,'MARTIN','SALESMAN',7698,to_date('28-9-1981','dd-mm-yyyy'),1250,1400,30);
INSERT INTO EMP_P VALUES
(7698,'BLAKE','MANAGER',7839,to_date('1-5-1981','dd-mm-yyyy'),2850,NULL,30);
INSERT INTO EMP_P VALUES
(7782,'CLARK','MANAGER',7839,to_date('9-6-1981','dd-mm-yyyy'),2450,NULL,10);
INSERT INTO EMP_P VALUES
(7788,'SCOTT','ANALYST',7566,to_date('13-07-87','dd-mm-yyyy' ),3000,NULL,20);
INSERT INTO EMP_P VALUES
(7839,'KING','PRESIDENT',NULL,to_date('17-11-1981','dd-mm-yyyy'),5000,NULL,10);
INSERT INTO EMP_P VALUES
(7844,'TURNER','SALESMAN',7698,to_date('8-9-1981','dd-mm-yyyy'),1500,0,30);
INSERT INTO EMP_P VALUES
(7876,'ADAMS','CLERK',7788,to_date('13-07-87', 'dd-mm-yyyy'),1100,NULL,20);
INSERT INTO EMP_P VALUES
(7900,'JAMES','CLERK',7698,to_date('3-12-1981','dd-mm-yyyy'),950,NULL,30);
INSERT INTO EMP_P VALUES
(7902,'FORD','ANALYST',7566,to_date('3-12-1981','dd-mm-yyyy'),3000,NULL,20);
INSERT INTO EMP_P VALUES
(7934,'MILLER','CLERK',7782,to_date('23-1-1982','dd-mm-yyyy'),1300,NULL,10);


--------------------
--Create table DEPT_P
--------------------

DROP TABLE IF EXISTS DEPT_P;

CREATE TABLE DEPT_P
       (DEPTNO NUMBER(2) CONSTRAINT PK_DEPT_P PRIMARY KEY,
	DNAME VARCHAR2(25) ,
	LOC VARCHAR2(13) ) ;
	
INSERT INTO DEPT_P (DEPTNO, DNAME, LOC) values (10, 'ACCOUNTING', 'NEW YORK');
INSERT INTO DEPT_P VALUES (20,'RESEARCH','DALLAS');
INSERT INTO DEPT_P VALUES (30,'SALES','CHICAGO');
INSERT INTO DEPT_P VALUES (40,'OPERATIONS','BOSTON');

--------------------
--Create table customers
--------------------
DROP TABLE IF EXISTS customers;

CREATE TABLE customers
( customer_id number(10) NOT NULL,
  last_name varchar2(50) NOT NULL,
  first_name varchar2(50) NOT NULL,
  favorite_website varchar2(50),
  CONSTRAINT customers_pk PRIMARY KEY (customer_id));
  
  
  INSERT INTO customers
(customer_id, last_name, first_name, favorite_website)
VALUES
(4000,'Jackson','Joe','www.techonthenet.com');

INSERT INTO customers
(customer_id, last_name, first_name, favorite_website)
VALUES
(5000,'Smith','Jane','www.digminecraft.com');

INSERT INTO customers
(customer_id, last_name, first_name, favorite_website)
VALUES
(6000,'Ferguson','Samantha','www.bigactivities.com');

INSERT INTO customers
(customer_id, last_name, first_name, favorite_website)
VALUES
(7000,'Reynolds','Allen','www.checkyourmath.com');

INSERT INTO customers
(customer_id, last_name, first_name, favorite_website)
VALUES
(8000,'Anderson','Paige',NULL);

INSERT INTO customers
(customer_id, last_name, first_name, favorite_website)
VALUES
(9000,'Johnson','Derek','www.techonthenet.com');


--Testcase :01 : Simple use of rownum
SELECT ROWNUM, customers.*
FROM customers
WHERE customer_id > 4500;
---------------------------------------------

--Testcase :02 : Simple use of rownum with order by. Records display will be sorted on last name and not on rownum.
SELECT ROWNUM, customers.*
FROM customers
WHERE customer_id > 4500
ORDER BY last_name;
---------------------------------------------

-- Testcase :03 : ROWNUM with subquery
SELECT ROWNUM, a.*
FROM (SELECT customers.*
      FROM customers
      WHERE customer_id > 4500
      ORDER BY last_name) a;
      
---------------------------------------------      
-- Testcase :04 : ROWNUM with subquery. Outer query has subset fo columns and some concatenation as well.
SELECT ROWNUM, a.customer_id, a.first_name ||''||a.last_name as customer_name, favorite_website 
FROM (SELECT customers.*
      FROM customers
      WHERE customer_id > 4500
      ORDER BY last_name) a;
      
---------------------------------------------
--  Testcase :05 : ROWNUM with subquery. Outer query is limiting rows based on rownum.
SELECT rownum, a.*
FROM (SELECT customers.*
      FROM customers
      WHERE customer_id > 4500
      ORDER BY last_name) a
WHERE ROWNUM < 3;


---------------------------------------------
--  Testcase :06 : ROWNUM with subquery. Outer query is limiting rows based on rownum.
-- Will show last two records.
-- Notable : The rownum will be 1 and 2 thus the actual rownum of customer table is not effective. The rownums are based on return set of subquery.

SELECT rownum, a.*
FROM (SELECT customers.*
      FROM customers
      WHERE customer_id > 4500
      ORDER BY last_name DESC) a
WHERE ROWNUM < 3;

---------------------------------------------

-- Testcase :07 : Same query as above but this time subquer does not have ALIAS. 
-- Will show last two records.
-- Notable : The rownum will be 1 and 2 thus the actual rownum of customer table is not effective. The rownums are based on return set of subquery.
-- 

SELECT *
FROM (SELECT customers.*
      FROM customers
      WHERE customer_id > 4500
      ORDER BY last_name DESC)
WHERE ROWNUM < 3;

---------------------------------------------
-- Testcase :08 : Update 

CREATE TABLE CUSTOMERS_2
AS
SELECT * FROM CUSTOMERS;

SELECT rownum, customers_2.* FROM customers_2;

      
UPDATE customers_2
SET customer_id = ROWNUM;

SELECT rownum, customers_2.* FROM customers_2;

---------------------------------------------

-- Testcase :08 : Update based on returned set from subquery using row_number function


CREATE TABLE CUSTOMERS_3
AS
SELECT * FROM CUSTOMERS;

SELECT rownum, customers_3.* FROM customers_3;
-----------------
UPDATE customers_3 c
SET customer_id = (
  SELECT r
  FROM (
    SELECT customer_id, ROW_NUMBER() OVER (ORDER BY customer_id DESC) AS r
    FROM customers_3
  ) t
  WHERE t.customer_id = c.customer_id
);
-----------------
SELECT rownum, customers_3.* FROM customers_3;

---------------------------------------------
-- Testcase : 11 ROW_NUMBER

SELECT rownum, deptno, ename, empno, ROW_NUMBER()
   OVER (PARTITION BY deptno ORDER BY empno) AS Employee_id
   FROM emp_p;

---------------------------------------------

-- Testcase : 12 ROW_NUMBER
SELECT rownum, ename FROM 
   (SELECT ename, ROW_NUMBER() over (order by ename) R FROM emp_p)
   WHERE R BETWEEN 10 and 12;

---------------------------------------------
-- Testcase 13
-- ROWNUM with joins
   
SELECT rownum, emp_p.ename, dept_p.dname
FROM emp_p join dept_p
on(emp_p.deptno = dept_p.deptno);

---------------------------------------------

-- Testcase 13
-- ROWNUM with joins in subquery.

SELECT rownum, B.ename, B.dname
FROM (SELECT rownum, emp_p.ename, dept_p.dname
FROM dept_p join emp_p
on(dept_p.deptno = emp_p.deptno)) B
WHERE rownum < 3;
---------------------------------------------

-- Testcase 14 : Use of DISTINCT 
 
SELECT ROWNUM, deptno
FROM (SELECT DISTINCT deptno FROM emp_p);
---------------------------------------------
-- Testcase 15 : Use of NULL LAST

SELECT ROWNUM, empno, ename, sal, comm
FROM (
  SELECT empno, ename, sal,comm
  FROM emp_p
  ORDER BY comm NULLS LAST
)
WHERE ROWNUM <= 12;

---------------------------------------------
-- Testcase 15 : Use of NULL FIRST
-- This time we will get 

SELECT ROWNUM, empno, ename, sal, comm
FROM (
  SELECT empno, ename, sal,comm
  FROM emp_p
  ORDER BY comm NULLS FIRST
)
WHERE ROWNUM <= 12;
---------------------------------------------

-- Cleanup
DROP TABLE DEPT_P, EMP_P, CUSTOMERS_3, CUSTOMERS_2, CUSTOMERS;

