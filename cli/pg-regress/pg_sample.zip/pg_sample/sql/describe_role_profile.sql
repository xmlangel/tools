-- Verify: \du/\du+ show "Profile <name>" in Attributes

-- Drop quietly (no NOTICE in stdout)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'psql_role_profile') THEN
    EXECUTE 'DROP ROLE psql_role_profile';
  END IF;
END$$;

CREATE ROLE psql_role_profile LOGIN;

-- Baseline: should show "Profile default"
\du psql_role_profile
\du+ psql_role_profile

-- Coexistence with another attribute
ALTER ROLE psql_role_profile SUPERUSER;
\du psql_role_profile

DROP ROLE psql_role_profile;

CREATE PROFILE basic_profile_test;
CREATE USER test23 IDENTIFIED BY 'test' PROFILE basic_profile_test;
\du test23

DROP USER test23;
DROP PROFILE basic_profile_test;
