--
--compatible oracle group by test
--
SET client_min_messages TO 'WARNING';
drop table if exists students;
create table students(student_id varchar(20),student_name varchar(40),student_pid int);
insert into students values('20200201','李四',1), ('20200202','张三',1), ('20200203','李四',2), ('20200204','张三',2);
select student_name from students group by student_pid;
select student_id,student_name from students group by student_id;

--add primary key
ALTER TABLE students ADD CONSTRAINT stu_id PRIMARY KEY (student_id);
select student_id,student_name from students group by student_id;
select student_id,student_name from students group by student_id,student_name order by student_id;
select student_name from students group by student_id;
select student_name from students group by student_pid;

--clean up
drop table students;
RESET client_min_messages;
