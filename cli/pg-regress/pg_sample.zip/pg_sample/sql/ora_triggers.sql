--
-- ORA_TRIGGERS
--

CREATE TABLE trig_employee (
    emp_id    NUMBER PRIMARY KEY,
    emp_name  VARCHAR2(20),
    emp_role  VARCHAR2(20)
);

CREATE TABLE action_audit (
    audit_id    SERIAL PRIMARY KEY,
    description VARCHAR2(100)
);

--
-- BEFORE statement-level trigger
--
CREATE TRIGGER trg_before_stmt_insert_log
    BEFORE INSERT ON trig_employee
BEGIN
    DBMS_OUTPUT.PUT_LINE('BEFORE STMT: Inserting into trig_employee table');
END;
/

INSERT INTO trig_employee (emp_id, emp_name, emp_role) VALUES
  (1001, 'Alice', 'new'),
  (1002, 'Bob', 'new');

SELECT * FROM trig_employee ORDER BY emp_id;

-- Try dropping the trigger's function
DROP FUNCTION trg_before_stmt_insert_log_trig_employee; -- This should fail

DROP TRIGGER trg_before_stmt_insert_log;

--
-- AFTER statement-level trigger
--
CREATE TABLE trigger_audit (
    audit_id    SERIAL PRIMARY KEY,
    trigger_type VARCHAR2(30),
    message      VARCHAR2(100)
);

CREATE TRIGGER trg_after_stmt_change_audit
    AFTER INSERT OR UPDATE OR DELETE ON trig_employee
DECLARE
    v_action VARCHAR2(30);
BEGIN
    IF INSERTING THEN
        v_action := 'Inserted trig_employee(s)';
    ELSIF UPDATING THEN
        v_action := 'Updated trig_employee(s)';
    ELSIF DELETING THEN
        v_action := 'Deleted trig_employee(s)';
    END IF;

    INSERT INTO trigger_audit (trigger_type, message)
    VALUES ('AFTER STMT', v_action);
END;
/

INSERT INTO trig_employee VALUES (1003, 'Charlie', 'new');
UPDATE trig_employee SET emp_name = 'Charles' WHERE emp_id = 1003;
DELETE FROM trig_employee WHERE emp_id = 1003;

SELECT * FROM trigger_audit ORDER BY audit_id;

DROP TRIGGER trg_after_stmt_change_audit;
DROP TABLE trigger_audit;

--
-- BEFORE row-level trigger
--
CREATE TRIGGER trg_before_row_onboard_role
    BEFORE INSERT ON trig_employee
    FOR EACH ROW
DECLARE
    v_next_id NUMBER;
BEGIN
    IF NEW.emp_role = 'new' THEN
        NEW.emp_role := 'onboarded';
    END IF;
    RETURN NEW;
END;
/

INSERT INTO trig_employee VALUES (1004, 'Diana', 'new');
INSERT INTO trig_employee VALUES (1005, 'Eli', 'new');

SELECT * FROM trig_employee ORDER BY emp_id;

DROP TRIGGER trg_before_row_onboard_role;

--
-- AFTER row-level trigger
--
CREATE TRIGGER trg_after_row_log_changes
    AFTER INSERT OR UPDATE OR DELETE ON trig_employee
    FOR EACH ROW
DECLARE
    v_empno trig_employee.emp_id%TYPE;
    v_changes VARCHAR2(100);
BEGIN
    IF INSERTING THEN
        v_empno := NEW.emp_id;
        v_changes := 'Inserted';
    ELSIF UPDATING THEN
      v_changes := '';
      v_empno := NEW.emp_id;

      IF NVL(OLD.emp_name, '-null-') != NVL(NEW.emp_name, '-null-') THEN
          v_changes := v_changes || 'name, ';
      END IF;

      IF NVL(OLD.emp_role, '-null-') != NVL(NEW.emp_role, '-null-') THEN
          v_changes := v_changes || 'role, ';
      END IF;

      IF v_changes IS NULL THEN
          v_changes := 'No changes detected';
      ELSE
          v_changes := 'Changed ' || RTRIM(v_changes, ', ');
      END IF;
    ELSIF DELETING THEN
        v_empno := OLD.emp_id;
        v_changes := 'Deleted';
    END IF;

    INSERT INTO action_audit (description)
    VALUES ('AFTER ROW: ' || v_changes || ' trig_employee #' || TO_CHAR(v_empno));
END;
/

INSERT INTO trig_employee VALUES (1006, 'Peters', 'analyst');
INSERT INTO trig_employee VALUES (1007, 'Aikens', 'analyst');

UPDATE trig_employee SET emp_name = 'Peters Updated' WHERE emp_id = 1006;
UPDATE trig_employee SET emp_role = 'senior analyst' WHERE emp_id = 1007;

SELECT * FROM trig_employee WHERE emp_id IN (1006, 1007);

DELETE FROM trig_employee WHERE emp_id IN (1006, 1007);

SELECT * FROM action_audit ORDER BY audit_id;

DROP TRIGGER trg_after_row_log_changes;

--
-- INSTEAD OF trigger
--
CREATE VIEW employee_view AS SELECT emp_id, emp_name FROM trig_employee;

CREATE TRIGGER trg_instead_of_insert_summary_view
    INSTEAD OF INSERT ON employee_view
    FOR EACH ROW
DECLARE
    v_empno trig_employee.emp_id%TYPE;
    v_empname trig_employee.emp_name%TYPE;
    v_emprole trig_employee.emp_role%TYPE;
BEGIN
    v_empno := NEW.emp_id;
    v_empname := NEW.emp_name;
    v_emprole := 'view_insert';
    INSERT INTO trig_employee VALUES (v_empno, v_empname, v_emprole);

    INSERT INTO action_audit (description)
    VALUES ('INSTEAD OF: Inserted via view: ' || v_empname);
END;
/

INSERT INTO employee_view VALUES (1008, 'Fiona');
INSERT INTO employee_view VALUES (1009, 'George');

SELECT * FROM trig_employee WHERE emp_id IN (1008, 1009) ORDER BY emp_id;
SELECT * FROM action_audit ORDER BY audit_id;

DROP TRIGGER trg_instead_of_insert_summary_view;
DROP VIEW employee_view;

DROP TABLE trig_employee;
DROP TABLE action_audit;
