
-- ---------- Cleanup ----------
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'test_user') THEN
    EXECUTE 'DROP ROLE test_user';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'test_user2') THEN
    EXECUTE 'DROP ROLE test_user2';
  END IF;

  IF EXISTS (SELECT 1 FROM ag_profile WHERE prfname = 'RENAMED_PROF') THEN
    EXECUTE 'DROP PROFILE RENAMED_PROF CASCADE';
  END IF;
  IF EXISTS (SELECT 1 FROM ag_profile WHERE prfname = 'TEST_PROFILE') THEN
    EXECUTE 'DROP PROFILE TEST_PROFILE CASCADE';
  END IF;
END$$;

-- ---------- Create ----------
CREATE PROFILE test_profile;

-- View should show uppercase names only
SELECT DISTINCT profile FROM dba_profiles WHERE profile IN ('DEFAULT','TEST_PROFILE') ORDER BY 1;

-- WHERE: uppercase matches, lowercase doesn't
SELECT EXISTS (SELECT 1 FROM dba_profiles WHERE profile = 'TEST_PROFILE');
SELECT EXISTS (SELECT 1 FROM dba_profiles WHERE profile = 'test_profile');

-- DDL: accept either case for PROFILE
CREATE USER test_user  IDENTIFIED BY 'a' PROFILE TEST_PROFILE;
CREATE USER test_user2 IDENTIFIED BY 'b' PROFILE test_profile;

-- Both users should map to the same (uppercase) profile
SELECT r.rolname || '|' || p.prfname
FROM pg_authid r
JOIN ag_profile p ON p.oid = r.rolprofile
WHERE r.rolname IN ('test_user','test_user2')
ORDER BY r.rolname;

-- ---------- Rename (update) ----------
ALTER PROFILE test_profile RENAME TO renamed_prof;

-- After rename, uppercase display and lookup should reflect new name
SELECT DISTINCT profile FROM dba_profiles WHERE profile IN ('TEST_PROFILE','RENAMED_PROF') ORDER BY 1;
SELECT EXISTS (SELECT 1 FROM dba_profiles WHERE profile = 'RENAMED_PROF');
SELECT EXISTS (SELECT 1 FROM dba_profiles WHERE profile = 'TEST_PROFILE');

-- Users should now map to RENAMED_PROF automatically (same OID renamed)
SELECT r.rolname || '|' || p.prfname
FROM pg_authid r
JOIN ag_profile p ON p.oid = r.rolprofile
WHERE r.rolname IN ('test_user','test_user2')
ORDER BY r.rolname;

-- ---------- Drop (delete) ----------
-- CASCADE should drop the profile and reassign users to DEFAULT
DROP PROFILE RENAMED_PROF CASCADE;

-- Users should now map to DEFAULT
SELECT r.rolname || '|' || p.prfname
FROM pg_authid r
JOIN ag_profile p ON p.oid = r.rolprofile
WHERE r.rolname IN ('test_user','test_user2')
ORDER BY r.rolname;

-- Final cleanup
DROP ROLE test_user;
DROP ROLE test_user2;