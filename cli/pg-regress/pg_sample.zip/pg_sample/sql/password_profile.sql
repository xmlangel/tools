--
-- Password Profile Tests
--

-- ******************* ag_profile *******************


-- DEFAULT PROFILE
SELECT * FROM ag_profile;


-- CREATE PROFILE (DEFAULT limits)
CREATE PROFILE testprf1;

-- CREATE PROFILE (Explicit DEFAULT limits)
CREATE PROFILE testprf2 LIMIT
    FAILED_LOGIN_ATTEMPTS DEFAULT
    PASSWORD_LOCK_TIME DEFAULT
    PASSWORD_LIFE_TIME DEFAULT
    PASSWORD_GRACE_TIME DEFAULT
    PASSWORD_REUSE_TIME DEFAULT
    PASSWORD_REUSE_MAX DEFAULT
    PASSWORD_VERIFY_FUNCTION DEFAULT;

-- CREATE PROFILE (UNLIMITED limits)
CREATE PROFILE testprf3 LIMIT
    FAILED_LOGIN_ATTEMPTS UNLIMITED
    PASSWORD_LOCK_TIME UNLIMITED
    PASSWORD_LIFE_TIME UNLIMITED
    PASSWORD_GRACE_TIME UNLIMITED
    PASSWORD_REUSE_TIME UNLIMITED
    PASSWORD_REUSE_MAX UNLIMITED;

-- CREATE PROFILE (Multiple Variable limits)
CREATE PROFILE testprf4 LIMIT
    FAILED_LOGIN_ATTEMPTS 3
    PASSWORD_LOCK_TIME 1
    PASSWORD_LIFE_TIME 7
    PASSWORD_GRACE_TIME 2
    PASSWORD_REUSE_TIME 3
    PASSWORD_REUSE_MAX 6
    PASSWORD_VERIFY_FUNCTION NULL;

-- CREATE PROFILE (In valid case)
CREATE PROFILE testprf4; -- Already exist
CREATE PROFILE DEFAULT; -- Invalid name
CREATE PROFILE 4; -- Invalid name

SELECT prfname, prffailedloginattempts, prfpasswordlocktime,
       prfpasswordlifetime, prfpasswordgracetime, prfpasswordreusetime,
       prfpasswordreusemax, prfpasswordverifyfuncdb, prfpasswordverifyfunc
FROM ag_profile;

-- ALTER PROFILE ( Unlimited )
ALTER PROFILE testprf2 LIMIT
    FAILED_LOGIN_ATTEMPTS UNLIMITED
    PASSWORD_LOCK_TIME UNLIMITED
    PASSWORD_LIFE_TIME UNLIMITED
    PASSWORD_GRACE_TIME UNLIMITED
    PASSWORD_REUSE_TIME UNLIMITED
    PASSWORD_REUSE_MAX UNLIMITED;

-- ALTER PROFILE ( DEFAULT )
ALTER PROFILE testprf3 LIMIT
    FAILED_LOGIN_ATTEMPTS DEFAULT
    PASSWORD_LOCK_TIME DEFAULT
    PASSWORD_LIFE_TIME DEFAULT
    PASSWORD_GRACE_TIME DEFAULT
    PASSWORD_REUSE_TIME DEFAULT
    PASSWORD_REUSE_MAX DEFAULT
    PASSWORD_VERIFY_FUNCTION DEFAULT;

-- ALTER PROFILE ( Variable Limits )
ALTER PROFILE testprf4 LIMIT
    FAILED_LOGIN_ATTEMPTS 2
    PASSWORD_LOCK_TIME 2.5
    PASSWORD_LIFE_TIME 0.5
    PASSWORD_GRACE_TIME 2.3
    PASSWORD_REUSE_TIME 1.5
    PASSWORD_REUSE_MAX 8
    PASSWORD_VERIFY_FUNCTION DEFAULT;

SELECT prfname, prffailedloginattempts, prfpasswordlocktime,
       prfpasswordlifetime, prfpasswordgracetime, prfpasswordreusetime,
       prfpasswordreusemax, prfpasswordverifyfuncdb, prfpasswordverifyfunc
FROM ag_profile;

--
-- Password Verification Function Tests
--
-- Valid Function
CREATE OR REPLACE FUNCTION verify_password(user_name varchar,
new_password varchar, old_password varchar)
RETURNS boolean
LANGUAGE plpgsql IMMUTABLE
AS
$$
BEGIN
  IF (length(new_password) < 5)
  THEN
    RAISE EXCEPTION 'too short';
    RETURN false;
  END IF;

  IF substring(new_password FROM old_password) IS NOT NULL
  THEN
    RAISE EXCEPTION 'includes old password';
    RETURN false;
  END IF;
  RETURN true;
END;
$$;

ALTER PROFILE testprf3 LIMIT 
    PASSWORD_VERIFY_FUNCTION verify_password;

SELECT prfname, proname
FROM ag_profile, pg_proc
WHERE prfname = 'testprf3'
AND pg_proc.oid = ag_profile.prfpasswordverifyfunc;

-- Invalid Function (Too Few Params)
CREATE OR REPLACE FUNCTION func_few_input_params(user_name varchar,
new_password varchar)
RETURNS boolean
LANGUAGE plpgsql IMMUTABLE
AS
$$
BEGIN
  RETURN true;
END;
$$;

ALTER PROFILE testprf3 LIMIT
    PASSWORD_VERIFY_FUNCTION verify_password;

SELECT prfname, proname
FROM ag_profile, pg_proc
WHERE prfname = 'testprf3'
AND pg_proc.oid = ag_profile.prfpasswordverifyfunc;

-- Invalid Function (Wrong Return Type)
CREATE OR REPLACE FUNCTION func_return_int(user_name varchar,
new_password varchar, old_password varchar)
RETURNS int  
LANGUAGE plpgsql IMMUTABLE
AS
$$
BEGIN
  RETURN 1;
END;
$$;

ALTER PROFILE testprf3 LIMIT
    PASSWORD_VERIFY_FUNCTION verify_password;

SELECT prfname, proname
FROM ag_profile, pg_proc
WHERE prfname = 'testprf3'
AND pg_proc.oid = ag_profile.prfpasswordverifyfunc;

-- ALTER profile (Invalid Cases)
--
-- profile which does not exit 
ALTER PROFILE testprf_not_exist LIMIT
    FAILED_LOGIN_ATTEMPTS 2;

-- Negative Limits
ALTER PROFILE testprf1 LIMIT FAILED_LOGIN_ATTEMPTS -1;
-- Unlimited for verify function
ALTER PROFILE testprf1 LIMIT PASSWORD_VERIFY_FUNCTION UNLIMITED;

-- RENAME PROFILE 
ALTER PROFILE testprf1 RENAME TO prf_renamed;
ALTER PROFILE testprf_not_exist RENAME TO prf_somename;

SELECT prfname FROM ag_profile
WHERE prfname = 'prf_renamed';

-- DROP PROFILE
DROP PROFILE testprf2;
DROP PROFILE testprf_not_exist;
DROP PROFILE IF EXISTS testprf_not_exist;
DROP PROFILE IF EXISTS testprf3 CASCADE;
DROP PROFILE IF EXISTS prf_renamed RESTRICT;

SELECT prfname, prffailedloginattempts, prfpasswordlocktime,
       prfpasswordlifetime, prfpasswordgracetime, prfpasswordreusetime,
       prfpasswordreusemax, prfpasswordverifyfuncdb, prfpasswordverifyfunc
FROM ag_profile;

--
-- Profile association with Users/Roles tests
-- 

-- DEFAULT user association
CREATE USER prftestu0;

SELECT rolname, rolprofile
FROM pg_roles
WHERE rolname='prftestu0';


-- DEFAULT role association
CREATE ROLE prftestr0;

SELECT rolname, rolprofile
FROM pg_roles
WHERE rolname='prftestr0';

-- Non-DEFAULT profile association
CREATE PROFILE user_prf_1;

CREATE USER prftest1 profile user_prf_1;

SELECT rolname, rolprofile
FROM pg_roles
WHERE rolname='prftest1';

-- Alter profile association
CREATE PROFILE user_prf_2;
ALTER USER prftest1 profile user_prf_2;

SELECT rolname, rolprofile
FROM pg_roles
WHERE rolname='prftest1';

-- CREATE USER with non-existing profile
CREATE USER prftest4 PROFILE prf_noexist;

SELECT rolname, rolprofile
FROM pg_roles
WHERE rolname='prftest4';

-- ALTER USER with non-existing profile
ALTER USER prftest1 PROFILE prf_noexist;

SELECT rolname, rolprofile
FROM pg_roles
WHERE rolname='prftest1';

-- DROP Profile which is associated with user 
-- RESTRICT (Not allow to delete)
DROP PROFILE user_prf_2;
DROP PROFILE user_prf_2 RESTRICT;
-- CASCADE (Delete and fall back to DEFAULT)
DROP PROFILE user_prf_2 CASCADE;
SELECT rolname, rolprofile
FROM pg_roles
WHERE rolname='prftest1';

-- USER/ROLE Lock Tests
-- 
-- Default status
SELECT rolname, rolaccountstatus
FROM pg_roles
WHERE rolname='prftest1';

-- Alter status to lock
ALTER USER prftest1 ACCOUNT LOCK;

SELECT rolname, rolaccountstatus
FROM pg_roles
WHERE rolname='prftest1';

-- Alter status to unlock
ALTER USER prftest1 ACCOUNT UNLOCK;

SELECT rolname, rolaccountstatus
FROM pg_roles
WHERE rolname='prftest1';

-- CREATE User locked
CREATE USER prftest4 ACCOUNT LOCK;
SELECT rolname, rolaccountstatus
FROM pg_roles
WHERE rolname='prftest4';


