 -- setup
CREATE TABLE test_table(i int, j int);
INSERT INTO test_table SELECT g, g FROM generate_series(1,1000) g;
CREATE INDEX test_table_idx ON test_table(i,j);

-- plain rebuild, should succeed
ALTER INDEX test_table_idx REBUILD;

-- ONLINE → maps to REINDEX CONCURRENTLY (will error inside a txn block); do it outside
\! printf ""
ALTER INDEX test_table_idx REBUILD ONLINE;

-- NOLOGGING and UNLOGGED accepted (no-op)
ALTER INDEX test_table_idx REBUILD NOLOGGING;
ALTER INDEX test_table_idx REBUILD UNLOGGED;

-- verify: index is valid and lives in the new tablespace
SELECT c.relname AS index_name,
       COALESCE(ts.spcname, 'pg_default') AS tablespace,
       ix.indisvalid
FROM   pg_class c
JOIN   pg_index ix ON ix.indexrelid = c.oid
LEFT JOIN pg_tablespace ts ON ts.oid = c.reltablespace
WHERE  c.relname = 'test_table_idx';

-- move back to default so tablespace can be dropped on all platforms
ALTER INDEX test_table_idx SET TABLESPACE pg_default;

-- cleanup
DROP INDEX test_table_idx;
DROP TABLE test_table;
