-- default for connect(can login) is true for user
CREATE USER regress_test_def_user_connect_1;
CREATE USER regress_test_def_user_connect_2;
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin, rolreplication, rolbypassrls, rolconnlimit, rolpassword, rolvaliduntil FROM pg_authid WHERE rolname = 'regress_test_def_user_connect_1' OR rolname = 'regress_test_def_user_connect_2';
CREATE USER regress_test_user_connect_1 WITH NOLOGIN;
CREATE USER regress_test_user_connect_2 WITH NOLOGIN;
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin, rolreplication, rolbypassrls, rolconnlimit, rolpassword, rolvaliduntil FROM pg_authid WHERE rolname = 'regress_test_user_connect_1' OR rolname = 'regress_test_user_connect_2';
GRANT CONNECT TO regress_test_user_connect_1, regress_test_user_connect_2;
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin, rolreplication, rolbypassrls, rolconnlimit, rolpassword, rolvaliduntil FROM pg_authid WHERE rolname = 'regress_test_user_connect_1' OR rolname = 'regress_test_user_connect_2';
REVOKE CONNECT FROM regress_test_user_connect_1, regress_test_user_connect_2;
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin, rolreplication, rolbypassrls, rolconnlimit, rolpassword, rolvaliduntil FROM pg_authid WHERE rolname = 'regress_test_user_connect_1' OR rolname = 'regress_test_user_connect_2';

-- clean up roles
DROP ROLE regress_test_user_connect_1;
DROP ROLE regress_test_user_connect_2;
DROP USER regress_test_def_user_connect_1;
DROP USER regress_test_def_user_connect_2;
