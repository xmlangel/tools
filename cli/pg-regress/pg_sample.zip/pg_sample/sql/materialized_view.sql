-- Basic IMMEDIATE + WITH DATA (populated right away)
CREATE MATERIALIZED VIEW omv_immediate_iwd BUILD IMMEDIATE
AS SELECT 10 AS x
WITH DATA;
SELECT * FROM omv_immediate_iwd;
DROP MATERIALIZED VIEW omv_immediate_iwd;

-- DEFERRED should ignore WITH DATA (acts like NO DATA)
CREATE MATERIALIZED VIEW omv_deferred_wd
  BUILD DEFERRED
AS SELECT 20 AS x
WITH DATA;
-- Should not be scannable yet
SELECT * FROM omv_deferred_wd;  -- expect "has not been populated"
REFRESH MATERIALIZED VIEW omv_deferred_wd;
SELECT * FROM omv_deferred_wd;
DROP MATERIALIZED VIEW omv_deferred_wd;

-- WITH NO DATA explicitly (no BUILD)
CREATE MATERIALIZED VIEW omv_no_build_wnd
AS SELECT 30 AS x
WITH NO DATA;
-- Not scannable until refresh
SELECT * FROM omv_no_build_wnd;  -- expect "has not been populated"
REFRESH MATERIALIZED VIEW omv_no_build_wnd;
SELECT * FROM omv_no_build_wnd;
DROP MATERIALIZED VIEW omv_no_build_wnd;

-- BUILD IMMEDIATE + WITH NO DATA (contradictory; NO DATA wins)
CREATE MATERIALIZED VIEW omv_immediate_wnd BUILD IMMEDIATE
AS SELECT 40 AS x
WITH NO DATA;
-- Not scannable until refresh
SELECT * FROM omv_immediate_wnd;  -- expect "has not been populated"
REFRESH MATERIALIZED VIEW omv_immediate_wnd;
SELECT * FROM omv_immediate_wnd;
DROP MATERIALIZED VIEW omv_immediate_wnd;

-- REFRESH clause forms: parser acceptance (no behavioral difference yet)

-- REFRESH (no options)
CREATE MATERIALIZED VIEW omv_r_none
  REFRESH
AS SELECT 1 AS x WITH NO DATA;
DROP MATERIALIZED VIEW omv_r_none;

-- REFRESH COMPLETE
CREATE MATERIALIZED VIEW omv_r_complete
  REFRESH COMPLETE
AS SELECT 1 AS x WITH NO DATA;
DROP MATERIALIZED VIEW omv_r_complete;

-- REFRESH ON DEMAND
CREATE MATERIALIZED VIEW omv_r_ondemand
  REFRESH ON DEMAND
AS SELECT 1 AS x WITH NO DATA;
DROP MATERIALIZED VIEW omv_r_ondemand;

-- REFRESH COMPLETE ON DEMAND
CREATE MATERIALIZED VIEW omv_r_complete_ondemand
  REFRESH COMPLETE ON DEMAND
AS SELECT 1 AS x WITH NO DATA;
DROP MATERIALIZED VIEW omv_r_complete_ondemand;

-- Clause order permutations

-- REFRESH ... then BUILD IMMEDIATE
CREATE MATERIALIZED VIEW omv_order1
  REFRESH COMPLETE ON DEMAND
  BUILD IMMEDIATE
AS SELECT 50 AS x WITH DATA;
SELECT * FROM omv_order1;
DROP MATERIALIZED VIEW omv_order1;

-- BUILD DEFERRED then REFRESH (still NO DATA until explicit refresh)
CREATE MATERIALIZED VIEW omv_order2
  BUILD DEFERRED
  REFRESH COMPLETE
AS SELECT 60 AS x WITH DATA;
SELECT * FROM omv_order2;  -- expect "has not been populated"
REFRESH MATERIALIZED VIEW omv_order2;
SELECT * FROM omv_order2;
DROP MATERIALIZED VIEW omv_order2;
